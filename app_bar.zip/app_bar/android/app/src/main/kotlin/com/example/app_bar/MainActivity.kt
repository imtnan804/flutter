package com.example.app_bar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
