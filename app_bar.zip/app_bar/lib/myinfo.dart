import 'dart:convert'; // Import the json library
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'User Form',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: UserForm(),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final List<Map<String, String>> profiles;

  const ProfilePage({Key? key, required this.profiles}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Profiles'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: ListView.builder(
        itemCount: profiles.length,
        itemBuilder: (context, index) {
          // Check the status to determine the color and icon
          bool isActive = profiles[index]['status'] == 'Active';
          return ListTile(
            title: Text('Name: ${profiles[index]['name']}'),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Email: ${profiles[index]['email']}'),
                Text('Mobile: ${profiles[index]['mobile']}'),
                Text('Password: ${profiles[index]['password']}'),
                Row(
                  children: [
                    Text('Status: ', style: TextStyle(fontWeight: FontWeight.bold)),
                    Container(
                      padding: EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isActive ? Colors.green : Colors.red,
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            isActive ? Icons.check : Icons.close,
                            color: Colors.white,
                          ),
                          SizedBox(width: 5),
                          Text(
                            isActive ? 'Active' : 'Non-active',
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class UserForm extends StatefulWidget {
  @override
  _UserFormState createState() => _UserFormState();
}

class _UserFormState extends State<UserForm> {
  // Controllers for text fields
  TextEditingController _nameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _mobileController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  // Status variable to store active or non-active
  bool _isActive = true;

  // Function to store user data in SharedPreferences
  void _storeData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Retrieve the existing profiles from SharedPreferences
    List<String> storedProfiles = prefs.getStringList('profiles') ?? [];

    // Create a new profile map
    Map<String, String> newProfile = {
      'name': _nameController.text,
      'email': _emailController.text,
      'mobile': _mobileController.text,
      'password': _passwordController.text,
      'status': _isActive ? 'Active' : 'Non-active',
    };

    // Encode the new profile map to a JSON string
    String profileJson = jsonEncode(newProfile);

    // Add the new profile JSON string to the stored list of profiles
    storedProfiles.add(profileJson);

    // Save the updated list of profiles (as JSON strings) back to SharedPreferences
    await prefs.setStringList('profiles', storedProfiles);

    // Show a message indicating that the data is saved
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Data saved successfully!')));
  }

  // Function to load all profiles from SharedPreferences
  void _loadData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    List<String> storedProfiles = prefs.getStringList('profiles') ?? [];
    List<Map<String, String>> profiles = [];

    // Convert each stored JSON string back into a Map<String, String>
    for (String profileJson in storedProfiles) {
      Map<String, dynamic> profileMap = jsonDecode(profileJson);
      Map<String, String> profile = Map<String, String>.from(profileMap);
      profiles.add(profile);
    }

    // Navigate to the ProfilePage and pass the profiles list
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfilePage(profiles: profiles),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Form'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          IconButton(
            icon: Icon(Icons.visibility),
            onPressed: _loadData,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _mobileController,
              decoration: InputDecoration(labelText: 'Mobile Number'),
              keyboardType: TextInputType.phone,
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            Row(
              children: [
                Text('Status: ', style: TextStyle(fontWeight: FontWeight.bold)),
                Radio(
                  value: true,
                  groupValue: _isActive,
                  onChanged: (value) {
                    setState(() {
                      _isActive = value as bool;
                    });
                  },
                ),
                Text('Active'),
                Radio(
                  value: false,
                  groupValue: _isActive,
                  onChanged: (value) {
                    setState(() {
                      _isActive = value as bool;
                    });
                  },
                ),
                Text('Non-active'),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _storeData,
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}

