import 'package:flutter/material.dart';
import 'calculator.dart'; // Import the calculator.dart file
import 'grade_book.dart'; // Import the grade_book.dart file
import 'name.dart'; // Import the name.dart file (your new page)
import 'input.dart';
import 'submit.dart';
import 'myinfo.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Home Page'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Row(
          children: [
            Image.asset(
              'assets/logo.jpg', // Make sure to place your logo image in the assets folder.
              height: 40,
            ),
            const SizedBox(width: 10),
            Text(title),
          ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.deepPurple,
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/logo1.png', // Your logo path in the assets folder
                    height: 80,
                    width: 80,
                  ),
                  SizedBox(height: 10),
                  Text(
                    'BGNU',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                    ),
                  ),
                ],
              ),
            ),
            // Existing menu items
            ListTile(
              leading: const Icon(Icons.calculate),
              title: const Text('Calculator'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const CalculatorPage()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.book),
              title: const Text('Grade Book'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const GradeBookPage()),
                );
              },
            ),
            // New ListTile for the Name Page
            ListTile(
              leading: const Icon(Icons.account_circle),
              title: const Text('Name'),
              onTap: () {
                Navigator.pop(context); // Close the drawer when tapped
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => NamePage()), // Navigate to NamePage
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.account_circle),
              title: const Text('Input'),
              onTap: () {
                Navigator.pop(context); // Close the drawer when tapped
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => Input()), // Navigate to NamePage
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.account_circle),
              title: const Text('Submit'),
              onTap: () {
                Navigator.pop(context); // Close the drawer when tapped
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => Input1()), // Navigate to NamePage
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.account_circle),
              title: const Text('Data'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserForm()),
                );
              },
            ),
          ],
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: <Widget>[
                    const Text(
                      'About Us',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Baba Guru Nanak University (BGNU) ...', // Description remains unchanged
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 20),
                    Image.asset(
                      'assets/pic.jpg',
                      height: 150,
                      width: double.infinity,
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          // Footer Section
          Container(
            width: double.infinity,
            color: Colors.deepPurple,
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                const Text(
                  '© 2025 Your BGNU. All Rights Reserved.',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.normal,
                      color: Colors.white),
                ),
                const SizedBox(height: 5),
                const Text(
                  'Contact: info@yourcompany.com | Terms of Service | Privacy Policy',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
