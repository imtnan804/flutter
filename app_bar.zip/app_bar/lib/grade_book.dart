import 'package:flutter/material.dart';

class GradeBookPage extends StatelessWidget {
  const GradeBookPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Grade Book'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: <Widget>[
                // Title for Grade Book
                const Text(
                  'Grade Book',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),

                // DataTable with border and header background color
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black), // Solid border
                    borderRadius: BorderRadius.circular(8), // Rounded corners
                  ),
                  child: DataTable(
                    columnSpacing: 20, // Add some space between columns
                    decoration: BoxDecoration(
                      color: Colors.white, // Table background color
                    ),
                    headingRowColor: MaterialStateProperty.all(
                        Colors.deepPurple), // Header background color
                    columns: const [
                      DataColumn(label: Text('Student Name')),
                      DataColumn(label: Text('Subject')),
                      DataColumn(label: Text('Grade')),
                      DataColumn(label: Text('Comments')),
                    ],
                    rows: const [
                      DataRow(cells: [
                        DataCell(Text('Hamza')),
                        DataCell(Text('Math')),
                        DataCell(Text('A')),
                        DataCell(Text('Excellent')),
                      ]),
                      DataRow(cells: [
                        DataCell(Text('Awais')),
                        DataCell(Text('Science')),
                        DataCell(Text('B+')),
                        DataCell(Text('Good')),
                      ]),
                      DataRow(cells: [
                        DataCell(Text('Riasat')),
                        DataCell(Text('History')),
                        DataCell(Text('A-')),
                        DataCell(Text('Very Good')),
                      ]),
                      DataRow(cells: [
                        DataCell(Text('Shoaib')),
                        DataCell(Text('English')),
                        DataCell(Text('B')),
                        DataCell(Text('Needs Improvement')),
                      ]),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
