package com.example.imtnan

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
