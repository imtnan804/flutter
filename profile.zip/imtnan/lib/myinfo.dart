import 'dart:convert'; // Import the json library
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'User Form',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: UserForm(),
    );
  }
}

// ProfilePage to display all saved profiles
class ProfilePage extends StatelessWidget {
  final List<Map<String, String>> profiles;

  const ProfilePage({Key? key, required this.profiles}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Profiles'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: profiles.isEmpty
          ? Center(child: Text("No profiles found."))
          : ListView.builder(
        itemCount: profiles.length,
        itemBuilder: (context, index) {
          bool isActive = profiles[index]['status'] == 'Active';
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            elevation: 3,
            child: ListTile(
              title: Text('Name: ${profiles[index]['name']}'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Email: ${profiles[index]['email']}'),
                  Text('Mobile: ${profiles[index]['mobile']}'),
                  Text('Password: ${profiles[index]['password']}'),
                  Row(
                    children: [
                      Text('Status: ', style: TextStyle(fontWeight: FontWeight.bold)),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: isActive ? Colors.green : Colors.red,
                          shape: BoxShape.rectangle,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              isActive ? Icons.check : Icons.close,
                              color: Colors.white,
                            ),
                            SizedBox(width: 5),
                            Text(
                              isActive ? 'Active' : 'Non-active',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// UserForm to collect user data and save it
class UserForm extends StatefulWidget {
  @override
  _UserFormState createState() => _UserFormState();
}

class _UserFormState extends State<UserForm> {
  // Controllers for text fields
  TextEditingController _nameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _mobileController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  // Status variable to store active or non-active
  bool _isActive = true;

  // Function to store user data in SharedPreferences
  void _storeData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Retrieve existing profiles from SharedPreferences
    List<String> storedProfiles = prefs.getStringList('profiles') ?? [];

    // Create a new profile map
    Map<String, String> newProfile = {
      'name': _nameController.text,
      'email': _emailController.text,
      'mobile': _mobileController.text,
      'password': _passwordController.text,
      'status': _isActive ? 'Active' : 'Non-active',
    };

    // Encode the new profile map to a JSON string
    String profileJson = jsonEncode(newProfile);

    // Append the new profile JSON string to the stored list of profiles
    storedProfiles.add(profileJson);

    // Save the updated list of profiles
    await prefs.setStringList('profiles', storedProfiles);

    // Show a confirmation message
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Profile saved successfully!')));

    // Clear the form fields after saving
    _nameController.clear();
    _emailController.clear();
    _mobileController.clear();
    _passwordController.clear();
    setState(() {
      _isActive = true;
    });
  }

  // Function to load all profiles from SharedPreferences
  void _loadData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    List<String> storedProfiles = prefs.getStringList('profiles') ?? [];
    List<Map<String, String>> profiles = [];

    // Convert each stored JSON string back into a Map<String, String>
    for (String profileJson in storedProfiles) {
      Map<String, dynamic> profileMap = jsonDecode(profileJson);
      profiles.add(Map<String, String>.from(profileMap));
    }

    // Navigate to the ProfilePage and pass the list of profiles
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfilePage(profiles: profiles),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Form'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          IconButton(
            icon: Icon(Icons.visibility),
            onPressed: _loadData,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _mobileController,
              decoration: InputDecoration(labelText: 'Mobile Number'),
              keyboardType: TextInputType.phone,
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            Row(
              children: [
                Text('Status: ', style: TextStyle(fontWeight: FontWeight.bold)),
                Radio(
                  value: true,
                  groupValue: _isActive,
                  onChanged: (value) {
                    setState(() {
                      _isActive = value as bool;
                    });
                  },
                ),
                Text('Active'),
                Radio(
                  value: false,
                  groupValue: _isActive,
                  onChanged: (value) {
                    setState(() {
                      _isActive = value as bool;
                    });
                  },
                ),
                Text('Non-active'),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _storeData,
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
