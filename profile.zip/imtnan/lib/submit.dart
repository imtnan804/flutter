import 'package:flutter/material.dart';

class Input1 extends StatefulWidget {
  const Input1({super.key});

  @override
  _Input1State createState() => _Input1State();
}

class _Input1State extends State<Input1> {
  final TextEditingController _controller = TextEditingController();
  String _inputText = '';

  void _submitInput() {
    setState(() {
      _inputText = _controller.text;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: const Text('Input'),
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                controller: _controller,
                decoration: const InputDecoration(
                  labelText: 'Enter your name',
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitInput,
                child: const Text('Submit'),
              ),
              const SizedBox(height: 20),
              Text(
                'You entered: $_inputText',
                style: const TextStyle(fontSize: 18),
              ),
            ],
          ),
        ),
      ),
    );
  }
}